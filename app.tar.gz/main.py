import flet as ft
from flet import TextField
from flet_core.control_event import ControlEvent
from datetime import datetime

PI_DIGITS = "31415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823066470938446095505822317253594081284811174502841027019385211055596446229489549303819644288109756659334461284756482337867831652712019091456485669234603486104543266482133936072602491412737245870066063155881748815209209628292540917153643678925903600113305305488204665213841469519415116094330572703657595919530921861173819326117931051185480744623799627495673518857527248912279381830119491"

leaderboard = []

def main(page: ft.Page) -> None:
    page.title = 'PI game'
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.theme_mode = 'dark'

    current_index = 0
    best_score = 0
    best_time = None
    start_time = None

    def submit_guess(e: ControlEvent) -> None:
        nonlocal current_index, best_score, best_time, start_time
        user_guess = text_input.value

        if user_guess == PI_DIGITS[current_index]:
            current_index += 1
            message_label.value = f"Correct! Next digit:"
            text_input.value = ''
        else:
            elapsed_time = datetime.now() - start_time
            elapsed_seconds = elapsed_time.total_seconds()

            if current_index > best_score:
                best_score = current_index
                best_time = elapsed_seconds
                best_score_label.value = f"Best Score: {best_score}"
                best_time_label.value = f"Best Time: {elapsed_seconds:.2f} seconds"
            elif current_index == best_score and (best_time is None or elapsed_seconds < best_time):
                best_time = elapsed_seconds
                best_time_label.value = f"Best Time: {elapsed_seconds:.2f} seconds"
            
            message_label.value = f"Wrong! Game over. You guessed {current_index} digits correctly."
            guessed_right_label.value = f"You guessed right these digits:\n{PI_DIGITS[:current_index]}"
            leaderboard.append((current_index, elapsed_seconds))
            leaderboard_label.value = "Leaderboard:\n" + "\n".join([f"{score} digits in {time:.2f} seconds" for score, time in sorted(leaderboard, reverse=True)[:5]])
            text_input.value = ''
            text_input.disabled = True
            submit_button.disabled = True
            restart_button.visible = True
        
        page.update()
    
    def restart_game(e: ControlEvent) -> None:
        nonlocal current_index, start_time
        current_index = 0
        start_time = datetime.now()
        text_input.value = ''
        text_input.disabled = False
        submit_button.disabled = False
        message_label.value = "Start guessing the digits of Pi!"
        restart_button.visible = False
        guessed_right_label.value = ''
        page.update()

    title = ft.Text(
        value="Pi Game",
        size=60,
        weight=ft.FontWeight.BOLD,
        text_align=ft.TextAlign.CENTER,
        color=ft.colors.CYAN
    )

    best_score_label = ft.Text(
        value=f"Best Score: {best_score}",
        size=30,
        text_align=ft.TextAlign.CENTER
    )
    
    best_time_label = ft.Text(
        value=f"Best Time: {best_time}" if best_time else "Best Time: ?",
        size=30,
        text_align=ft.TextAlign.CENTER
    )

    text_input: TextField = TextField(value='', text_align=ft.TextAlign.CENTER, width=300, hint_text="Enter a digit", on_submit=submit_guess)
    message_label: ft.Text = ft.Text(value="Start guessing the digits of Pi!", text_align=ft.TextAlign.CENTER)
    guessed_right_label: ft.Text = ft.Text(value="", text_align=ft.TextAlign.CENTER)
    leaderboard_label: ft.Text = ft.Text(value="Leaderboard:\n", text_align=ft.TextAlign.CENTER)

    submit_button = ft.IconButton(ft.icons.CHECK, on_click=submit_guess)
    restart_button = ft.IconButton(ft.icons.REPLAY, on_click=restart_game, visible=False)

    page.add(
        ft.Column(
            [
                title,
                best_score_label,
                best_time_label,
                ft.Container(height=100),
                message_label,
                text_input,
                ft.Row([submit_button, restart_button], alignment=ft.MainAxisAlignment.CENTER),
                guessed_right_label,
                leaderboard_label
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )
    )

    # Start the timer when the game starts
    start_time = datetime.now()


ft.app(target=main)
